def max_sum(A):
	#for i in A:
	#	if (i < -1000) or (i > 1000):
	#		return
	if len(A) == 1:
		print(A[0])
		return
  # 최대 구간 합 리턴
	p = [] #prefix sum들을 저장할 리스트
	       #p[i]에는 prefix_sum A[0] +... A[i]값을 저장'
	#sums= []
	temp = 0
	for i in range(0,len(A)):
		temp += A[i]
		p.append(temp)
	
	M = max(p)
	for i in range(1,len(A)): # i = 1 
		for j in range(i,len(A)): # i = 1 j = 1 # i부터 끝까지
			if M < (p[j]-p[i-1]):
				M = (p[j]-p[i-1])
	
#	print(p)
	print(M)
	

A = [int(x) for x in input().split()]

#for i in A:
#	if i <= -1000 or i >= 1000:
#		exit()
#print(A)
#A = [0]
max_sum(A)