n = int(input())

sticks = []

for i in range(n):
	sticks.append(list(map(int,input().split())))

sticks = sorted(sticks, key=lambda sticks : sticks[1])
minnum_of_nails = 1
#print(sticks)

min_right_point = sticks[0]
for stick in sticks:
	if min_right_point[1] < stick[0]:
		min_right_point = stick
		minnum_of_nails += 1
print(minnum_of_nails)
		
		
#sticks = [[2,3],[2,4],[3,5],[4,6],[5,6],[6,7],[7,9],[9,10],[10,11],[10,12]]
#sticks = sorted(sticks, key=lambda sticks : sticks[1])
#left = [2,2,3,4,5,6,7,9,10,10]
#right = [3,4,5,6,6,7,9,10,11,12]

#sticks = [[2,3],[2,4],[3,5],[4,6],[5,6],[6,7],[7,9],[9,10],[10,11],[10,12]]
#sticks = sorted(sticks, key=lambda sticks : sticks[1])
#left = [2,2,3,4,5,6,7,9,10,10]
#right = [3,4,5,6,6,7,9,10,11,12]
		
		
		

	
		
		
		
	




		
